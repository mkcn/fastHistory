from bashlex import parser, tokenizer

parse = parser.parse
parsesingle = parser.parsesingle
split = parser.split
